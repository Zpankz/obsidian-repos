---
permalink: plugins/random-note
---
Random note is a [[Core plugins|core plugin]] that opens a random note within your vault. Rediscover notes to add new insights, or link to recently added notes.

To open a random note, click **Open random note** ( ![[obsidian-icon-dice.svg#icon]] ) in the [[Ribbon]].