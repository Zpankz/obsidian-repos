---
permalink: plugins/outline
---
Outline is a [[Core plugins|core plugin]] that lists the headings in the active note.

To navigate to that section in the note, click on the heading in the outline.

To rearrange sections in the note, click and drag the heading within the outline.