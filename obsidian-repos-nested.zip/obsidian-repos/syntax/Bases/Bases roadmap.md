---
permalink: bases/roadmap
---
The [[Introduction to Bases|Bases]] plugin is still in development. We expect many changes and improvements to Bases over the coming months, and longer than usual [[Early access versions|early access]] phases. [See roadmap.](https://obsidian.md/roadmap/)