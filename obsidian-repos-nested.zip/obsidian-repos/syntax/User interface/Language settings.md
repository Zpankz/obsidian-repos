---
aliases:
  - Concepts/Interface language
permalink: language
---
The Obsidian interface has been translated to various languages by [[Credits#Translators|our amazing volunteer translators]]. You can change the interface language either in **Settings** ( ![[lucide-settings.svg#icon]] ) → **General** or when you create a new vault.

Is your language missing from the list? Are you seeing untranslated snippets of text? [[Translations|Help us translate Obsidian into your language]].