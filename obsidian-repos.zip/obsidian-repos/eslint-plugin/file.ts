// This file is a workaround for @typescript-eslint/rule-tester virtual file inclusion.
// It ensures that <tsconfigRootDir>/file.ts is included in the project for type-aware linting.
export const workaround = true;
