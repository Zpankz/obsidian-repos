---
permalink: financial-contributions
---
This page explains the ways you can support the development of Obsidian financially.

One of the best ways to support the team is through one or more of our paid products.

- If you need to sync notes across your devices, consider a subscription for [[Introduction to Obsidian Sync|Obsidian Sync]].
- If you want to publish your notes to the world, consider a subscription for [[Introduction to Obsidian Publish|Obsidian Publish]].
- If you use Obsidian at work, consider supporting Obsidian by purchasing a [[Commercial license|Commercial license]].

We understand that you might not be interested in any of our other paid products right now, though we'd love to know how we can change that! If you still want to support Obsidian, consider getting a [[Catalyst license]].
