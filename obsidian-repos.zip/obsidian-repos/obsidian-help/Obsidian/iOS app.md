---
permalink: ios
---
This help article is legacy and only serves as a bridge to avoid breaking links. For information on the mobile app, please see [[Sync your notes across devices]].

## Sync

For information on syncing on the iOS app, please see [[Sync your notes across devices]].
