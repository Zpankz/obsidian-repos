---
permalink: official-site
---
Obsidian’s official website is at https://obsidian.md

There you can:

- [Download](https://obsidian.md/download) the latest installer if your installer version is old.
- Register an account, and access your [account dashboard](https://obsidian.md/account), if you want to purchase [[Catalyst license]], [[Commercial license]], [[Introduction to Obsidian Sync|Obsidian Sync]], or [[Introduction to Obsidian Publish|Obsidian Publish]].
