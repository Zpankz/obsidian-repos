Hi, welcome to Obsidian!

---

## I’m interested in Obsidian

First of all, tell me a little bit about what's your experience with note-taking apps like?

-> [[No prior experience|I have no prior experience]] testing

-> [[From standard note-taking|I’ve used note-taking apps like Evernote and OneNote]]

-> [[From plain-text note-taking|I have used plain-text based apps]]

---

## Official Help Site
Check out the complete [Obsidian documentation](https://help.obsidian.md/) online, available in multiple languages.

---

## What is this place?

This is a sandbox vault in which you can test various functionalities of Obsidian. 

> [!Warning]
> Your changes will not be saved, so please don't take actual notes in this vault.

> [!Note] Beta vault - contributions are welcome!
> This sandbox vault is in beta!
> 
> If you spot a typo or a mistake, feel free to submit a pull request [here](https://github.com/obsidianmd/obsidian-docs/tree/master/Sandbox).


